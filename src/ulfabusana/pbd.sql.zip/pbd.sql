-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 11, 2020 at 09:24 PM
-- Server version: 5.0.67
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `databarang`
--

CREATE TABLE IF NOT EXISTS `databarang` (
  `kode` int(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis` varchar(10) NOT NULL,
  `harga` int(12) NOT NULL,
  `tglmasuk` int(11) NOT NULL,
  `tglkadaluarsa` int(11) NOT NULL,
  `jumlah` int(4) NOT NULL,
  `kondisi` varchar(10) NOT NULL,
  PRIMARY KEY  (`kode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `databarang`
--

INSERT INTO `databarang` (`kode`, `nama`, `jenis`, `harga`, `tglmasuk`, `tglkadaluarsa`, `jumlah`, `kondisi`) VALUES
(1, 'pulpen', 'ATK', 2000, 20190402, 20200302, 3, 'Baik'),
(2, 'Gamis', 'Jubah', 150000, 20200122, 20230417, 1, 'Baik'),
(3, 'Sosis Jumbo', 'Makanan', 10000, 20200325, 20210118, 15, 'Baik');

-- --------------------------------------------------------

--
-- Table structure for table `datapelanggan`
--

CREATE TABLE IF NOT EXISTS `datapelanggan` (
  `kode` int(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `alamat` varchar(40) NOT NULL,
  `notelp` int(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `jeniskelamin` varchar(2) NOT NULL,
  `tgldaftar` int(11) NOT NULL,
  PRIMARY KEY  (`kode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datapelanggan`
--

INSERT INTO `datapelanggan` (`kode`, `nama`, `alamat`, `notelp`, `email`, `jeniskelamin`, `tgldaftar`) VALUES
(1, 'akusiapa', 'jember', 2147483647, 'siapaaja@gmail.com', 'P', 20190601),
(2, 'Ani', 'Surabaya', 2147483647, 'ani@yahoo', 'P', 20191227),
(3, 'Pandu', 'Situbondo', 2147483647, 'pandu@gmail', 'L', 20191228);

-- --------------------------------------------------------

--
-- Table structure for table `pelajar`
--

CREATE TABLE IF NOT EXISTS `pelajar` (
  `nim` varchar(9) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `pswrd` varchar(16) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `email` varchar(20) NOT NULL,
  `jenkel` varchar(1) NOT NULL,
  PRIMARY KEY  (`nim`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelajar`
--

INSERT INTO `pelajar` (`nim`, `nama`, `pswrd`, `alamat`, `email`, `jenkel`) VALUES
('1', 'pbd', 'sukasuka', 'dirumahaja', '@yahoo', 'L'),
('E31192024', 'Riska', '543', 'jbr', 'risk@', 'P'),
('E3119', 'serahdah', 'qwe', 'adoh', 'kepodih', 'L'),
('2', 'we', '1', 'adohkono', '@', 'P'),
('134', 'q', 'w', 'e', 'r', 'L'),
('', 'ok', 'pass', 'sana', '@@@', 'P'),
('E642', 'ok', 'pass', 'sana', '@@@', 'P');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `no` int(3) NOT NULL auto_increment,
  `uname` varchar(10) NOT NULL,
  `password` varchar(8) NOT NULL,
  PRIMARY KEY  (`no`),
  UNIQUE KEY `uname` (`uname`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`no`, `uname`, `password`) VALUES
(1, 'pemilik', '1');
